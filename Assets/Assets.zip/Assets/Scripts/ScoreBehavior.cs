using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreBehavior : MonoBehaviour
{

    public static float scoreValue = GameManager.Score;
    Text score;
    // Start is called before the first frame update
    void Awake() 
    {
        scoreValue = GameManager.Score;
    }

    void Start()
    {
        score = GetComponent<Text> ();
    }

    // Update is called once per frame
    void Update()
    {
        score.text = "Score : " + scoreValue;
    }

}
